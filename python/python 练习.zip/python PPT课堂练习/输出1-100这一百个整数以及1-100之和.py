x=1
sum=0
while x<=100:         #第1次   x=1   P后 x=2
    print(x,end=",")  #第1次   x=2   P后 x=3
    if x%10==0:       #第99次  x=99  P后 x=100
        print()       #第100次 x=100 P后 x=101
    sum=sum+x
    x=x+1
print("sum=",sum)
