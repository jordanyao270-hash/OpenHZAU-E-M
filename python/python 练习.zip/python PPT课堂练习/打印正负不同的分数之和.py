x=1
sign=1
sum=0
while x<=100:
    sum=sum+sign*1/x
    x=x+1
    sign=-sign
print("sum=%.4f"%sum)
