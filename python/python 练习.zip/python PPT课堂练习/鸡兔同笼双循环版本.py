for i in range(0,31):#代表鸡
    for j in range(0,31):#代表兔
        if i+j==30 and i*2+j*4==90:
            print(i,j)
