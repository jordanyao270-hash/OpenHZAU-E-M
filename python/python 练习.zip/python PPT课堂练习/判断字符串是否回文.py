def huiwen(s):
    a=""
    for i in s:
        a=i+a
    if a==s:
        return True
    else:
        return False
s=input()
a=huiwen(s)
print(a)
