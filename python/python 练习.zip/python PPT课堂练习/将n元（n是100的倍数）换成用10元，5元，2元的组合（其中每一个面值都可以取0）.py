n=int(input())
t=0
for x in range(0,n//10+1):
    for y in range(0,n//5+1):
        for z in range(0,n//2+1):
            if x*10+y*5+z*2==n:
                t+=1
print(t)
