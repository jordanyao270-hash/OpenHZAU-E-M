def fab(n):
    s=[1,1]
    for i in range(2,n):
        s.append(s[i-1]+s[i-2])
    return s
a=int(input())
b=fab(a)
c=[str(i) for i in b]#注意这里的i一定要转化为字符串类型
d=" ".join(c)
print(d)

def fab(n):
    s=[]
    for i in range(0,n):
        if i==0 or i==1:
            s.append(1)
        else:
            s.append(s[i-1]+s[i-2])
    return s
a=int(input())
b=fab(a)
c=[str(i) for i in b]
d=" ".join(c)
print(d)
