x=1
sum=0
sign=1
while x<=966:
    sum=sum+sign*x
    x=x+1
    sign=(-1)*sign
print("sum=%d"%sum)
    
    
