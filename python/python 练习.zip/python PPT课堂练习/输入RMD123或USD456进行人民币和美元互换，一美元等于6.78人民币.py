a=input()
if a[0] is "R":
    b=a[3:]
    c=float(b)/6.78
    print("USD"+str(c))
else:
    d=a[3:]
    e=float(d)*6.78
    print("RMB"+str(e))









    
    
