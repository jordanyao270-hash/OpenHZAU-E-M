from random import *
b=100#在若干数求最大值，先假设一个较小的数为最大值的初值，然后将产生的每一个数与最大值比较，若大于初值则替换它
for i in range(1,11):
    a=randint(100,200)
    if a>b:
        b=a
print(b)
