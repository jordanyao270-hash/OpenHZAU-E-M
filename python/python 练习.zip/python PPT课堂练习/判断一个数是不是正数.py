a=input("a:")
a=int(a)
if(a>0):
    print(a,"是正数。")
else:
    print(a,"不是正数。")
