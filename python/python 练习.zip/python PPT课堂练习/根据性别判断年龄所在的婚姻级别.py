a,b=input().split(",")#这里的a,b不是一种类型所以用split不能用eval
c=int(a)
if b=="M":
    if 0<=c<=30:
        print("不着急")
    elif 30<c<=36:
        print("可以考虑了")
    elif 36<c<=120:
        print("快点吧")
    else:
        print("error")
elif b=="F":
    if 0<=c<=25:
        print("不着急")
    elif 25<=c<=30:
        print("可以考虑了")
    elif 30<c<=120:
        print("快点吧")
    else:
        print("error")
else:
    print("error")
