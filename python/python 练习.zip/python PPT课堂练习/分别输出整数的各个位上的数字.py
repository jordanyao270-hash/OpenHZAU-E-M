import math
a=eval(input("input data:"))
a3=a%10
a2=a//10%10
a1=a//100
print("百位:%d"%a1)
print("千位:%d"%a2)
print("个位:%d"%a3)
