num=int(input("请输入一个正整数:"))
for n in range(2,num+1):
    for x in range(2,n):
        if n%x==0:
            print("%d不是质数"%n)
            break
    else:
        print("%d是质数"%n)
