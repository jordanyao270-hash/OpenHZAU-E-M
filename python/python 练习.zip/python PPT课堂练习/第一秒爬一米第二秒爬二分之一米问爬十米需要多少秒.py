j=1
s1=0
while s1<=10:
    s1=s1+1/j
    j=j+1
print("爬10米需要%d秒"%(j-1))
