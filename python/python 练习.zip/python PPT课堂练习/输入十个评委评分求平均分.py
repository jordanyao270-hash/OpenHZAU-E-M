sum=0
for i in range(1,11):
    x=int(input())
    sum=sum+x
print("平均分为%f"%(sum/10))
