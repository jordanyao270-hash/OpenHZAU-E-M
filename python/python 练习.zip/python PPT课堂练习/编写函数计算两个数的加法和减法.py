def sumDiff(x,y):
    sum=x+y
    diff=x-y
    return sum,diff
num1,num2=eval(input())
s,d=sumDiff(num1,num2)
print(s,d)#s将获得return的第一个返回值sum,d将获得第二个返回值diff
