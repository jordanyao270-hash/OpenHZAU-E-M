def long(s):
    a=s.split(" ")#将这一句话的单词分别分隔出来
    b={}
    for i in a:
        b[i]=len(i)
    c=max(list(b.values()))
    for i in b:
        if b[i]==c:
            print(i,b[i])
s=input()
long(s)

def maxWords(s):
    w=[]
    w=s.split()
    max1=0
    for i in w:
        if len(i)>max1:
            j=i#这样只会输出最后一个长度最长的单词，即只会输出一个单词
    return j
a=input("请输入用空格间隔单词的句子:")
print(maxWords(a))
    
