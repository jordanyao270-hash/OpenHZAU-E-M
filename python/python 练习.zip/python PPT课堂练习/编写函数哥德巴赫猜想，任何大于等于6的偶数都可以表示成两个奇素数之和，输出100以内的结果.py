def prime(n):
    for i in range(2,n):
        if n%i==0:
            return False
    else:#这个else可以不要，不要这个else的话下一行要与for平齐
        return True

for i in range(6,101,2):
    for j in range(2,i+1):
        if prime(j)==True and prime(i-j)==True:
            print(j,i-j,i)
            
