PM=eval(input("input PM2.5:"))
if PM<35:
    print("空气质量优，建议户外运动")#if和else之间不能有除了if,elif,else之外的其他代码与它们平齐
elif PM<75:
    print("空气质量良好")
else:
    print("空气污染")
