a=int(input("input data:"))
week="MoTuWeThFrSaSu"
if a>0 and a<8:
    out=week[(a-1)*2:(a-1)*2+2]#星期一对应0,1
                               #星期二对应2，3
                               #星期三对应4，5
                               #星期四对应6，7
                               
    print(out)
else:
    print("input error")
