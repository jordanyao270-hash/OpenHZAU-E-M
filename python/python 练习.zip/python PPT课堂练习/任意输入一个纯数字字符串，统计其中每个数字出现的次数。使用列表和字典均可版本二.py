s=input("input string:")
A={}
for i in range(0,len(s)):
    if (s[i] in A)==False:
        A[s[i]]=1
    else:
        A[s[i]]=A[s[i]]+1
print(A)
