x=int(input("请输入一个三位正整数:"))
c=x%10
b=x//10%10
a=x//100
if a**3+b**3+c**3==x:
    print("该数是水仙花数")
         
else:
    print("该数不是水仙花数")
        
