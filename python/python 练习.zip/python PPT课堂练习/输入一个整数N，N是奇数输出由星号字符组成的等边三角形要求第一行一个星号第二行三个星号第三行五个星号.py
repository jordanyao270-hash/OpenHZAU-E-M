N=int(input())
for i in range(0,N+1):
    if i%2==0:
        continue
    else:
        print(i*"*")
