for j in range(1,1001):
    a=[]#空列表要放第一个循环内
    for i in range(1,j):
        if j%i==0:
            a.append(i)
    s=sum(a)
    if s==j:
        print(j)
