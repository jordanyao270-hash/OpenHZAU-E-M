for j in range(2,101):#大概率会考！！！
    for i in range(2,j):
        if j%i==0:
            print("%d不是质数"%j)
            break
    else:
        print("%d是质数"%j)
