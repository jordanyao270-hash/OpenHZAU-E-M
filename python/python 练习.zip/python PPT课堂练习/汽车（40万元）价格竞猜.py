a=eval(input())
b0=40
if a==b0:
    print("答对了!")
elif a>b0:
    print("太高了!")
else:
    print("太低了!")
