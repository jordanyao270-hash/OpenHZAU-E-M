sa=321//17
sb=321//27
r=321
si=0
sj=0
for i in range(1,sa+1):#代表长度为17米的材料数量
    for j in range(1,sb+1):
        c=321-i*17-j*27
        if c>=0:
            if c<r:
                r=c
                si=i
                sj=j
print(si,sj,r)
