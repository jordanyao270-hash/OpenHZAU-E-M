tem=input("请输入带符号的温度:")
print(tem)

if tem[-1] in ['c','C']:
    out=float(tem[0:-1])*1.8+32
    print("转换之后的华氏温度为:",out)
    
elif tem[-1] in ['f','F']:
    out=(float(tem[0:-1])-32)/1.8
    print("转换之后的摄氏温度为:",out)
else:
    print("输入格式错误!请重新输入!")
