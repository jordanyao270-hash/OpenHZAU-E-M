s=input()
for i in range(0,len(s)//2):
    if s[i]!=s[len(s)-1-i]:
        print("不是回文序列")
        break
else:
    print("是回文序列")

s=input()
a=list(s)
b=a.copy()#不能b=a,这样赋值赋值的是id地址，而里面的内容是一样的
a.reverse
if a==b:
    print("yes")
else:
    print("no")


s=input()
b=""
for i in s:
    b=i+b#如输入s为123456，则b第一次为1，第二次为21，第三次为321
for i in range(0,len(s)):
    if s[i]!=b[i]:
        print("no")
        break
else:
    print("yes")
