m=[]
for i in range(0,64):
    m.append(2**i)
print(sum(m))
