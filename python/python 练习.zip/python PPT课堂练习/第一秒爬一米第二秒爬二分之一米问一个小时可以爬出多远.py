s=0
for i in range(1,3601):
    s=s+1/float(i)
print("一小时可以爬%d米"%s)



j=1
s1=0
while j<=3600:#可以在其后面打上print("第%d秒开始时爬了%.2f米"%(j,s))
    s1=s1+1/j#可以在其后面打上print("第%d秒结束时爬了%.2f米"%(j,s))
    j=j+1
