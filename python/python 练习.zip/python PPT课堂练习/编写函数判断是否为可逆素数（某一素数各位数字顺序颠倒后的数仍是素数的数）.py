def prime(n):
    for i in range(2,n):
        if n%i==0:
            return False
    else:#这个else可以不要，不要这个else的话下一行要与for平齐
        return True
s=input()
a=s[::-1]#指的是把a给颠倒了
if prime(int(s))==True and prime(int(a))==True:#等号要写两个，True可以不加引号
    print("是可逆素数")
else:
    print("不是可逆素数")
