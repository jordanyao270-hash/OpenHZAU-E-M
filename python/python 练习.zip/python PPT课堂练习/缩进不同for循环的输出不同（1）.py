j="*"
for i in range(3):
    print(i)
    print(j)
#0
#*
#1
#*
#2
#*
