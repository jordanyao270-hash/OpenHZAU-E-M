def add1(m,n):
    if m>n:
        m,n=n,m
    s=0
    for i in range(m,n+1):
        s=s+i
    return s#return与def之间只有一个缩进
x,y=eval(input())
print(add1(x,y))
