s=input().split(" ")#此时输入的是列表
n=0
for i in s:
    if len(i)>n:#这样的话如果输入的单词有两个长度相同的只会输出第一个单词，若变成>=则会输出后边的那个单词
        n=len(i)
        a=i
print(a,n)
