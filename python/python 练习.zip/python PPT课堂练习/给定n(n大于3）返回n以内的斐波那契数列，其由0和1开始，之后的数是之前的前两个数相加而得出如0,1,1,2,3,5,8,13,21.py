n=input("input a number please:")
n=int(n)
N=[1,1]
while (N[-1]+N[-2])<=n:
    m=N[-1]+N[-2]
    N.append(m)
M=[str(i) for i in N]#只能是str(i)不能是int(i)
print(",".join(M)+",")

    
    
    
