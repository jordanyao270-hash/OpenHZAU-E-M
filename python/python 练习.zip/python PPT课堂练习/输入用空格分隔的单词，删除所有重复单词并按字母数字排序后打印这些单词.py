n=input().split(" ")
a=set(n)
b=list(a)
b.sort()
c=[]
for i in b:
    c.append(i)
print(" ".join(c))
