hour=eval(input("请输入停车小时数:"))
if int(hour)!=hour:#也可以用ceil函数
    hour=int(hour)+1
    print("实际计费小时数:%d"%hour)#若这里的print缩进，则hour为整数时不会有print。也可写成print("实际计费小时数:",hour)
else:
    print("hour")
