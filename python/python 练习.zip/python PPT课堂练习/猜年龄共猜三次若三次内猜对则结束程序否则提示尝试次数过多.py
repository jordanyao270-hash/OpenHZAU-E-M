t=1
while t<=3:
    age=int(input("guess age:"))#如果把这一行写在最前面则相当于只输入一次年龄
    if age<40:
        print("think bigger...")
    elif age>40:
        print("think smaller...")
    else:
        print("yes!")
        break#不能写成continue因为continue只结束本次的，而break是全部终止
    t=t+1
else:
    print("you have tried too many times...")
