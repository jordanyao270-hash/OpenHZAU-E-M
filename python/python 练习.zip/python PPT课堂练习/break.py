var=10
while var>0:
    var=var-1
    if var==5 or var==8:
        break#break用来终止循环语句
    print("当前值:",var)#只会输出9
