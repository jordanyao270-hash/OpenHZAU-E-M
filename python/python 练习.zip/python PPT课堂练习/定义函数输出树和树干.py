def treetop(n,p):
    for i in range(1,n+1):
        print(" "*(n-i)+p*(2*i-1))
def tree(n,p,m,q,x):#n是树有几行，p代表树用什么填充，m代表树干有几行，q代表树干用什么填充，x代表会打印几个树的形状
    for i in range(1,x+1):
        treetop(n,p)
    for i in range(1,m+1):
        print(" "*(n-1)+q)
        return 9,2,3#这样返回的是一个元组(9,2,3)

a=tree(4,"T",5,"H",3)
print(a)
            
