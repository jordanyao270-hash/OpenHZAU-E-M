sum=0
for i in range(1,11):
    i="2"*i
    sum=sum+int(i)
print(sum)
