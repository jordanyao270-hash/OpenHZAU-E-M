from calendar import*             #calendar.weekday(year,month,day)返回给定日期的日期码
                                  #0对应星期一，6对应星期日
y=input("请输入年:")
m=input("请输入月:")
d=input("请输入日:")
Dic={0:"星期一",1:"星期二",2:"星期三",\
    3:"星期四",4:"星期五",5:"星期六",\
    6:"星期天"}
if y.isdigit() and m.isdigit() and d.isdigit and 1<=int(m)<=12 and 1<=int(d)<=31:
    x=weekday(int(y),int(m),int(d))
    y=Dic.get(x)
    print(y)
else:
    print("input error")
