for hen in range(0,31):
    if 2*hen+(30-hen)*4==90:
        print("hen:",hen,"rabbit",30-hen)
