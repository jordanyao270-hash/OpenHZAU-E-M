from random import *
s="0123456789"
x=""
for i in range(0,6):
    a=randint(0,9)
    x=x+s[a]
print(x)


from random import *
s="0123456789"
y=""
for i in range(0,6):
    c=choice(s)
    y=y+c
print(y)

from random import *
s="0123456789"
m=""
z=sample(s,6)#若要求输出不重复的六个字符则用sample
for i in z:
    m=m+i
print(m)
