x=1
sum=0
while x<=100:
    sum=sum+1/x
    x+=1
print("\nsum=",sum)
