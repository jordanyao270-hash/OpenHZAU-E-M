N=int(input())
s1=0
s2=0
for i in range(0,N+1):
    if i%2==0:
        s1=s1+i
    else:
        s2=s2+i
print("奇数和为%d,偶数和为%d"%(s2,s1))
