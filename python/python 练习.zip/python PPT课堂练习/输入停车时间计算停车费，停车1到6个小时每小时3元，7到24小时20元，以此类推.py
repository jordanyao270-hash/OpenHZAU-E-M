hours=eval(input("请输入停车时间:"))
days,hour=divmod(hours,24)
if hours<=6:
    if (int(hour)!=hour):
        fee=days*20+(int(hour)+1)*3
    else:
        fee=days*20+hours*3
else:
    fee=(days+1)*20
print("你停车的小时数为:{},收费为{}元。".format(hours,fee))
