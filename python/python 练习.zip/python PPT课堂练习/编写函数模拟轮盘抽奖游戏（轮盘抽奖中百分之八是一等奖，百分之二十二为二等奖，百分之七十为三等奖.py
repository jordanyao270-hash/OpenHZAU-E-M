bonus={"一等奖":(0,0.08),"二等奖":(0.08,0.3),"三等奖":(0.3,1.0)}
from random import *

def choujiang(bonus):
    a=random()#意思是生成0到1之间的随机小数
    print(a)
    for i in bonus:#b是字典里面的键
        c=bonus.get(i)#c是字典里面的值
        if c[0]<=a<c[1]:#因为各个区域有重合所以一半取等于一半不取等于
            return i

print(choujiang(bonus))
#以下为验证占比的部分
c={}
for i in range(100):
    a=choujiang(bonus)
    if a in c:
        c[a]+=1
    else:
        c[a]=1
print(c)
