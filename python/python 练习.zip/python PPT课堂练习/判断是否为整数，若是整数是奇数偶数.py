import math
a=eval(input())
if a%2==1:
    print("奇数")
elif a%2==0:
    print("偶数")
else:
    print("输入错误")
