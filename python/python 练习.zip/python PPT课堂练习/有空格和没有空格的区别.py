sum=0
for i in range(1,11):
    sum+=i
print(sum)#若print前面有空格则每次的sum都会被打印出来，而此时只打印一次
