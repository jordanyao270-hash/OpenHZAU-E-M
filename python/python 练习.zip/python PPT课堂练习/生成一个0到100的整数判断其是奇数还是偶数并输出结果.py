import random
a=random.randint(0,100)
if a%2==0:
    print("随机生成数"+str(a)+"是偶数。")
else:
    print("随机生成数"+str(a)+"是偶数。")
