tup=("+","-","*","/")
while True:
    a=float(input("请输入第一个操作数:"))
    b=float(input("请输入第二个操作数:"))
    t=input("请输入运算符号:")
    if t in tup:
        dic={"+":a+b,"-":a-b,"*":a*b,"/":a/b}
        print("%f%s%f=%.4f"%(a,t,b,dic.get(t)))
    else:
        print("输入错误")
        break
