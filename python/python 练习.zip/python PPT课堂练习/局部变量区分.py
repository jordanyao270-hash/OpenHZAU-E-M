ls=["car","trunk"]#是局部变量
def func(a):
    ls=[]
    ls.append(a)
    return
print(func("bus"))#输出None
print(ls)#输出["car","trunk","bus"]
