from random import *
z=sample(range(1,61),10)
z.sort()
print(z)


a=set()
while len(a)<10:#第一次进来长度为0所以不是小于等于10
    b=randint(1,60)
    a.add(b)
c=list(a)
c.sort()#不能print(c.sort())
print(c)#或者不要上一行直接print(sorted(c))
