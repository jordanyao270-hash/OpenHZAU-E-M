a=int(input("input data:"))
month="JanFebMarAprMayJunJulAugSepOctNovDec"
if a>0 and a<13:
    out=month[(a-1)*3:(a-1)*3+3]#out一定要放在if后面，若放在month后面的话若a太大可能发生错误
                                #因为冒号后面是开区间，所以写成(a-1)*3+3
    print(out)#1月:0 1 2  2月:3 4 5  3月:6 7 8  可找到规律第一个数是(a-1)*3,第二个数是(a-1)*3+1,第三个数是(a-1)*3+2
else:
    print("input error")
      
