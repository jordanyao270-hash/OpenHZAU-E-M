import math
a,b,c=eval(input("input:"))
if a+b>c>a-b:
    p=(a+b+c)/2
    s=math.sqrt(p*(p-a)*(p-b)*(p-c))
    print("面积为:%.2f"%s)
else:
    print("不能构成三角形")
