import math

a=float(input("a="))
b=float(input("b="))
c=float(input("c="))
if a+b>c>a-b:
    p=(a+b+c)/2
    area=math.sqrt(p*(p-a)*(p-b)*(p-c))
    print("面积: %f" % area)
else:
    print("不能构成三角形")
