i=int(input())
if i>0:
    while i!=1:
        if i%2==1:
            i=i*3+1
        else:
            i=i/2
        print(i)
else:
    print("error")
