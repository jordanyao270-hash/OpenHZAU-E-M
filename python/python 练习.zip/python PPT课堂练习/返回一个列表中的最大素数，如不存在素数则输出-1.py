def prime(n):
    for i in range(2,n):
        if n%i==0:
            return False
    else:
        return True
def maxp(s):
    m=-1
    for i in s:
        if prime(i)==True and i>m:
            m=i
    return m
s=input().split(" ")
a=[]
for i in s:
    a.append(int(i))#这样就把s里面的字符串转化成数字了
                    #也可以用a=[int(i) for i in s]转化

print(maxp(a))
    
