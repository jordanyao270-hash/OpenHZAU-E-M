from random import *#导入随机数库
La=[]
for i in range(9,-1,-1):#注意因为会删除元素所以必须倒着来写
    a=randint(100,200)#产生a到b的随机正整数
    La.append(a)#将x追加到列表最后
for i in range(9,-1,-1):
    if La[i]%2==0:
        del La[i]
print(La)
