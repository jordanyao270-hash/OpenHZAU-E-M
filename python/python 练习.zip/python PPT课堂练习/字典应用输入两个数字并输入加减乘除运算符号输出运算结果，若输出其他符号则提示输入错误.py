f=["+","-","*","/"]#大概率会考!!!
a=float(input("请输入第一个操作数:"))
b=float(input("请输入第二个操作数:"))
c=input("请输入运算符号:")
D={"+":a+b,"-":a-b,"*":a*b,"/":a/b}
if c in f:
    x=D.get(c)
    print(str(a)+str(c)+str(b)+"="+str(x))
else:
    print("input error")
