def prime(n):
    for i in range(2,n):
        if n%i==0:
            return False
    else:#这个else可以不要，不要这个else的话下一行要与for平齐
        return True
s=int(input())
print(prime(s))
