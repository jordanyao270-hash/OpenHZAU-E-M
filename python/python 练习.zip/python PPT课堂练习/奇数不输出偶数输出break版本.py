for num in range(2,10):
    if num%2==0:
        print("Found an even number",num)
        break#这样的只能输出一行，而如果换成continue的话会把23456789的都输出
    print(str(num)+"*****")
