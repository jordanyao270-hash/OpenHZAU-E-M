from random import *
a=[]
for i in range(0,1000):
    b=randint(20,100)
    a.append(b)

c={}
for i in range(0,1000):
    if a[i] in c:
        c[a[i]]+=1
    else:
        c[a[i]]=1
print(c)
d=list(c.keys())
d.sort()
for i in d:
    print(i,c[i])


from random import *
a=[]
for i in range(0,1000):
    b=randint(20,100)
    a.append(b)
c=set(a)
d=list(c)
d.sort()
for i in c:
    print(i,a.count(i))
