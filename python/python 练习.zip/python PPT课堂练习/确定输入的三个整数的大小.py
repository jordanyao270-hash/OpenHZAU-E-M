a=int(input("Input a:"))
b=int(input("Input b:"))
c=int(input("Input c:"))
if a>b:
    if a>c:
        max=a
        if b>c:
            mid=b
            min=c
    else:
        max=c
        mid=a
        min=b
else:
    if b>c:
        max=b
        if a>c:
            mid=a
            min=c
    else:
        max=c
        mid=b
        min=a
print("max=",max,"mid=",mid,"min=",min)
