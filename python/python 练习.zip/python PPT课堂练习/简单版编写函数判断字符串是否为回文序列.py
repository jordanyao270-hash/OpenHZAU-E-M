def huiwen(s):
    for i in range(0,len(s)//2):
        if s[i]==s[len(s)-1-i]:
            return True
        else:
            return False
s=input()
a=huiwen(s)
print(a)
