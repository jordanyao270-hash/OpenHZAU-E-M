AA=["Comprehensive", "Polytechnic", "Comprehensive", "Comprehensive", "Comprehensive", \

      "Comprehensive", "Comprehensive", "Comprehensive", "Comprehensive", "Comprehensive",\

      "Normal", "Polytechnic", "Comprehensive", "Polytechnic", "Comprehensive", "Comprehensive", \

      "Comprehensive", "Comprehensive", "Comprehensive","Polytechnic",\

      "Polytechnic", "Polytechnic", "Polytechnic", "Normal", "Comprehensive", \

      "Agricultural and Forestry", "Polytechnic", "Comprehensive", "Polytechnic", "Polytechnic", \

      "Polytechnic", "Comprehensive", "Polytechnic", "Comprehensive", "Comprehensive", \

      "Polytechnic", "Agricultural and Forestry", "Nationalities", "Military"]
AA.sort()
print(AA)
