import math
a=input("input data:")
if int(a)>=100:
    a1=int(a[0])#若写为a1=a[0]则表示字符串
    a2=int(a[1])
    a3=int(a[2])
    if math.pow(a1,3)+math.pow(a2,3)+math.pow(a3,3)==int(a):
        print("yes")
    else:
        print("no")
else:
    print("input error")
