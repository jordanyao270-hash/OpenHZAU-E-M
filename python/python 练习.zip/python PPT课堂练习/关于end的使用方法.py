print("123")#print自带换行功能，不加end的话会自动换行输出
print(123)
print("1111",end=",")
print("1234")
#123
#123
#1111,1234
