n=input()
for x in range(0,int(n)//10+1):#必须用整除而不是/的原因是/之后虽然可以整除但是小数点后会保留两位数.00，所以会出现‘float' object can not be interpreted as an integer的报错
    for y in range(0,int(n)//20+1):
        for z in range(0,int(n)//50+1):
            if 10*x+20*y+50*z==int(n):
                print("x=",x,"y=",y,"z=",z)






