n=int(input("请输入数据的个数n="))
s=0
for i in range(1,n+1):
    m=float(input("Enter a number>>"))
    s=s+m
avg=s/n
print(avg)
