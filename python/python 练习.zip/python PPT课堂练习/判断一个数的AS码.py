a=input()
b=ord(a)
if 48<=b<=57:
    print("数字")
elif 65<=b<=90:
    print("大写")
elif 97<=b<=122:
    print("小写")
