from random import *#导入随机数库
a=[]
for i in range(1,11):
    b=randint(100,200)#产生a到b的随机正整数
    if b%2==1:
        a.append(b)#将x追加到列表最后
    else:
        continue
print(a)
