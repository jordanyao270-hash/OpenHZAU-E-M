from random import *
def catch(n=5,maxstep=10):
    p=[0 for i in range(0,5)]#意思是把5个0放入列表，代表五个洞
    a=randint(0,4)
    p[a]=1#意思是随机数生成的这个洞有狐狸
    for i in range(0,maxstep):
        b=int(input("请输入要抓的数字:"))
        if p[b]==1:
            print("恭喜你，抓到了！")
            break
        else:
            print("很遗憾，没抓到，明天再来吧！")
        c=choice([1,-1])
        if a==0:#意思是如果狐狸在第一个洞，下一次它只能到第二个洞
            new=1
        elif a==4:#意思是如果狐狸在第五个洞，下一次它只能到第四个洞
            new=3
        else:
            new=a+c
        p[a],p[new]=0,1#指的是有狐狸的洞变了
        a=new
    else:
        print("次数用完了")
catch(5,10)
        

