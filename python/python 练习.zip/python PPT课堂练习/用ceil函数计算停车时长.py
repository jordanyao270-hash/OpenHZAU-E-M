import math
hour=eval(input("请输入停车小时数:"))
if int(hour)!=hour:
    hour=math.ceil(hour)
    print("实际计费小时数:",hour)
else:
    print("hour")
