import math
r=eval(input("input data:"))
s=math.pi*pow(r,2)
l=2*math.pi*r
print("area is %.2f,cir is %.2f"%(s,l))
