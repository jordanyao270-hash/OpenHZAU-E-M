a=input("请输入一个十进制的整数:")
b=input("请输入一个十进制的整数:")
s=int(a)+int(b)#由于input返回的是一个字符串，需要先用int函数转换为数值后再进行计算
print("两数的和:"+str(s))#print函数输出拼接字符串时两个值的类型需要一致所以用str进行转换后输出，否则会出现“TypeError:"
