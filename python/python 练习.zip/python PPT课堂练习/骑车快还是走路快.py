x=int(input("请输入距离:"))
a=30+x/4+20
b=x/2
if a>b:
    print("Walk")
elif a<b:
    print("Bike")
else:
    print("All")
