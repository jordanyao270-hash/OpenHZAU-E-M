from random import *
s=set([])
for i in range(int(input("N:"))):
    s.add(randint(1,1000))
print(s)
print(sorted(s))
