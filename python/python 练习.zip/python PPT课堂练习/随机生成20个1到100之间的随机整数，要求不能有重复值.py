from random import *
a=[]
while len(a)<20:#因为不能有重复值所以不知道会重复几次因此不能用for要用while
    b=randint(1,100)
    if b not in a:
        a.append(b)
print(a)


c=set()
while len(c)<20:#集合的方法不用判断是否会有重复值因为集合有唯一性
    b=randint(1,100)
    c.add(b)
print(list(c))


import random
x=[]
while len(x)<20:
    n=randint(1,100)
    if n not in x:
        x.append(n)
print(x)
print(len(x))
print(sorted(x))#不能写print(sort(x)),不能b=a.sort(),只能a.sort()
print(max(x),min(x),sum(x))
