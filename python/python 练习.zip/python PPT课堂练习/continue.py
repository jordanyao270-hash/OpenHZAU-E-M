var=10
while var>0:
    var=var-1
    if var==5 or var==8:
        continue#continue是跳过当前循环的剩余语句继续进行下一轮循环，是一个删除的效果，它的存在是为了删除满足循环条件下的某些不需要的成分
    print("当前值:",var)#输出9,7,6,4,3,2,1,0
