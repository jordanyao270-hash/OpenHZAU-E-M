h,v=eval(input("请输入身高和体重:"))
bmi=v/h/h
print("bmi为:",bmi)
if bmi<18.5:
    print("slim")
    
elif bmi<23:
    print("perfect")
    
else:
    print("fat")
               
