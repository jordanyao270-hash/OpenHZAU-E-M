sum=0
number=0
while number<20:
    number=number+1
    sum=sum+number
    if sum>100:
        break
print("The number is",number)
print("The sum is",sum)


s=0
for i in range(1,21):
    s=s+i
    print("%d,%d"%(i,s))
    if s>=100:
        break
