for i in range(1949,2020):
    if(i%4==0 and i%100!=0)or(i%400==0):
        print(i,end=",")
