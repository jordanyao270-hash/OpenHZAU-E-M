a=int(input("Input a:"))
b=int(input("Input b:"))
c=int(input("Input c:"))
if a<b:
    if b<c:
        max=c
    else:
        max=b
else:
    if a<c:
        max=c
    else:
        max=a
print("max=",max)
