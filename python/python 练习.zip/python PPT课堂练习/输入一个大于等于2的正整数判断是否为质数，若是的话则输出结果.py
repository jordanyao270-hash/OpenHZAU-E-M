n=int(input("请输入一个大于1的正整数:"))#质数是除了1和它本身不能被任何数整除的数
for x in range(2,n):
    if n%x==0:
        print("%d不是质数"%n)
        break
else:
    print("%d是质数"%n)#for函数是上面所有的都正常才会执行else
